#include <Windows.h>
#include "TeaEncrypt.h"

int main()
{
    const char *pPlainText = "hi";
    int nPlainLen = strlen(pPlainText);
    BYTE pKey[16];
    for (int i = 0; i < 16; i ++)
    {
        pKey[i] = i;
    }
    int nEncryptLen = oi_symmetry_encrypt2_len(strlen(pPlainText));
    BYTE *pCipherText = new BYTE[nEncryptLen];
    int nCipherLen = 0;


    oi_symmetry_encrypt2((const BYTE *)pPlainText, nPlainLen, pKey, pCipherText, &nCipherLen);

    BYTE *pDecodedText = new BYTE[nCipherLen];

    //descrypt
    memset(pDecodedText, 0, nCipherLen);
    int nDecodedLen = nCipherLen;  //ע�⣬���������Ҫ��ֵ��

    oi_symmetry_decrypt2(pCipherText, nCipherLen, pKey, pDecodedText, &nDecodedLen);


    //-
    delete pCipherText;
    pCipherText = NULL;

    delete pDecodedText;
    pDecodedText = NULL;
    return 0;
}